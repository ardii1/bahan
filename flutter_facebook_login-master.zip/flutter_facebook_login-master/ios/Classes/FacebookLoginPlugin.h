#import <Flutter/Flutter.h>

@interface FacebookLoginPlugin : NSObject<FlutterPlugin>
@end
