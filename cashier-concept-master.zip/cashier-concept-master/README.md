# Cashier Concept

A Flutter project, just wanted to make a cashier app even though just add product layout and the functionality.
with Sqflite and some basic form validation, image picker dependency and some beautiful flutter app.

## Getting Started

Its a whole flutter code, with dart language. actually this project can run just simply pull/ download the zip,
and run this under lib/main.dart

For help getting started with Flutter, view our 
[online documentation](https://flutter.dev/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.
