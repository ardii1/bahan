import "package:flutter/material.dart";

class ListProduct extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // Return the state to create new State

    return new _ListProduct();
  }

}

class _ListProduct extends State<ListProduct> {

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
    );
  }


}
